/*!
 * Domco Security Project Gruntfile
 * http://domco.us
 * @author Jason McCoy
 */

'use strict';

/**
 * Livereload and connect variables
 */
var LIVERELOAD_PORT = 35730;
var lrSnippet = require('connect-livereload')({
    port: LIVERELOAD_PORT
});
var mountFolder = function(connect, dir) {
    return connect.static(require('path').resolve(dir));
};

/**
 * Grunt module
 */
module.exports = function(grunt) {

    /**
     * Dynamically load npm tasks
     */
    require('load-grunt-tasks')(grunt);
    require('time-grunt')(grunt);
    require('matchdep').filterDev('grunt-*').forEach(grunt.loadNpmTasks);

    /**
     * Grunt config
     */
    grunt.initConfig({

        pkg: grunt.file.readJSON('package.json'),

        /**
         * Set project info
         */
        project: {
            src: 'src',
            app: 'app',
            assets: '<%= project.app %>/assets',
            css: ['<%= project.src %>/scss/style.scss'],
            js: ['<%= project.src %>/js/*.js']
        },

        /**
         * Project banner
         * Dynamically appended to CSS/JS files
         * Inherits text from package.json
         */
        tag: {
            banner: '/*!\n' + ' * <%= pkg.name %>\n' + ' * <%= pkg.title %>\n' + ' * <%= pkg.url %>\n' + ' * @author <%= pkg.author %>\n' + ' * @version <%= pkg.version %>\n' + ' * Copyright <%= pkg.copyright %>. <%= pkg.license %> licensed.\n' + ' */\n'
        },

        /**
         * Connect port/livereload
         * https://github.com/gruntjs/grunt-contrib-connect
         * Starts a local webserver and injects
         * livereload snippet
         */
        connect: {
            options: {
                port: 8005,
                hostname: '*'
            },
            livereload: {
                options: {
                    middleware: function(connect) {
                        return [lrSnippet, mountFolder(connect, 'app')];
                    }
                }
            }
        },

        /**
         * JSHint
         * https://github.com/gruntjs/grunt-contrib-jshint
         * Manage the options inside .jshintrc file
         */
        jshint: {
            files: ['src/js/*.js'],
            options: {
                jshintrc: '.jshintrc'
            }
        },

        /**
         * Bump package version, create tag, commit, push ...
         * https://github.com/vojtajina/grunt-bump
         */
        bump: {
            options: {
                files: ['package.json'],
                updateConfigs: [],
                commit: true,
                commitMessage: 'Release v%VERSION%',
                commitFiles: ['package.json'],
                createTag: true,
                tagName: 'v%VERSION%',
                tagMessage: 'Version %VERSION%',
                push: true,
                pushTo: 'upstream',
                gitDescribeOptions: '--tags --always --abbrev=1 --dirty=-d',
                globalReplace: false
            }
        },

        /**
         * Concatenate JavaScript files
         * https://github.com/gruntjs/grunt-contrib-concat
         * Imports all .js files and appends project banner
         */
        concat: {
            dev: {
                files: {
                    '<%= project.assets %>/js/scripts.min.js': '<%= project.js %>'
                }
            },
            options: {
                stripBanners: true,
                nonull: true,
                banner: '<%= tag.banner %>'
            }
        },

        /**
         * Uglify (minify) JavaScript files
         * https://github.com/gruntjs/grunt-contrib-uglify
         * Compresses and minifies all JavaScript files into one
         */
        uglify: {
            options: {
                banner: "<%= tag.banner %>"
            },
            dist: {
                files: {
                    '<%= project.assets %>/js/scripts.min.js': '<%= project.js %>'
                }
            }
        },

        /**
         * Compile Sass/SCSS files
         * https://github.com/gruntjs/grunt-contrib-sass
         * Compiles all Sass/SCSS files and appends project banner
         */
        sass: {
            dev: {
                options: {
                    style: 'expanded',
                    banner: '<%= tag.banner %>'
                },
                files: {
                    '<%= project.assets %>/css/style.min.css': '<%= project.css %>'
                }
            },
            dist: {
                options: {
                    style: 'compressed',
                    banner: '<%= tag.banner %>'
                },
                files: {
                    '<%= project.assets %>/css/style.min.css': '<%= project.css %>'
                }
            }
        },

        /**
         * Opens the web server in the browser
         * https://github.com/jsoverson/grunt-open
         */
        open: {
            server: {
                path: 'http://localhost:<%= connect.options.port %>'
            }
        },

        /**
         * Runs tasks against changed watched files
         * https://github.com/gruntjs/grunt-contrib-watch
         * Watching development files and run concat/compile tasks
         * Livereload the browser once complete
         */
        watch: {
            concat: {
                files: '<%= project.src %>/js/{,*/}*.js',
                tasks: ['concat:dev', 'jshint']
            },
            sass: {
                files: '<%= project.src %>/scss/{,*/}*.{scss,sass}',
                tasks: ['sass:dev']
            },
            livereload: {
                options: {
                    livereload: LIVERELOAD_PORT
                },
                files: ['<%= project.app %>/{,*/}*.html', '<%= project.assets %>/css/*.css', '<%= project.assets %>/js/{,*/}*.js', '<%= project.assets %>/{,*/}*.{png,jpg,jpeg,gif,webp,svg}']
            }
        },

        /**
         * A grunt task for removing unused CSS from your projects with UnCSS.
         * Works across multiple files and supports dynamically injected CSS via PhantomJS.
         * https://github.com/addyosmani/grunt-uncss
         */
        uncss: {
            dist: {
                files: {
                    'app/assets/css/style.min.css': ['app/login.html', 'app/index.html', 'app/index.php', 'app/index.php']
                }
            }
        },

        /**
         * Update your devDependencies and dependencies automatically with a grunt task
         * https://github.com/pgilad/grunt-dev-update
         */
        devUpdate: {
            main: {
                options: {
                    updateType: 'force', // force the update for outdated packages
                    reportUpdated: false, //don't report up-to-date packages
                    semver: true, //stay within semver when updating
                    packages: {
                        devDependencies: false, //only check for devDependencies
                        dependencies: true
                    },
                    packageJson: null, //use matchdep default findup to locate package.json
                    reportOnlyPkgs: [] //use updateType action on all packages
                }
            }
        }

    });

    /**
     * Default task
     * Run `grunt` on the command line
     */
    grunt.registerTask('default', ['sass:dev', 'jshint', 'concat:dev', 'connect:livereload', 'uncss', 'open', 'watch']);

    /**
     * Build task
     * Run `grunt build` on the command line
     * Then compress all JS/CSS files
     */
    grunt.registerTask('build', ['sass:dist', 'jshint', 'uglify', 'uncss', 'processhtml']);

};
