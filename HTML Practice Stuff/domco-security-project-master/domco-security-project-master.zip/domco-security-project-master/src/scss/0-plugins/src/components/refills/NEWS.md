## HEAD

## 0.0.2

- Fix errors caused by missing generator dependency in list generator
- Navigation refill: Keep search and sign up visible on mobile screens
- Navigation refill: Add dropdown menu
- Navigation refill: Add indication on currently selected nav item

## 0.0.1

- Initial release
