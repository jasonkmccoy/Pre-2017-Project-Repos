module Bitters
  VERSION = "0.10.1"
end
