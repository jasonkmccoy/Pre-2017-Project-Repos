$LOAD_PATH << File.join('../lib')

require 'bitters'
