module Refills
  VERSION = '0.0.2'
end
