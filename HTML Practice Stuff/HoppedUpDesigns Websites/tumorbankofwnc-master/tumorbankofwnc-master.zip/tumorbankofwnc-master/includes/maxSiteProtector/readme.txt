Max's Site Protector

Varsion 1.0

Usage:
	1. Open the maxProtector.class.php file and change the value of password variable.
	2. On every page you want to protect insert the following line at the beginning of your code:
			<?php require_once("maxProtector.class.php"); ?>

That's all!			